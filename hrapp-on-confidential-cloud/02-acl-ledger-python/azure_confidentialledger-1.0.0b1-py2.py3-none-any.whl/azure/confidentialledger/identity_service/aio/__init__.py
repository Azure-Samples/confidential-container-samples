# ------------------------------------
# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
# ------------------------------------


from ._client import ConfidentialLedgerIdentityServiceClient

__all__ = [
    "ConfidentialLedgerIdentityServiceClient",
]
