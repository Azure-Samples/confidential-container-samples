from devtools_testutils import AzureTestCase


class AsyncConfidentialLedgerTestCase(AzureTestCase):
    def __init__(self, *args, **kwargs):
        super(AsyncConfidentialLedgerTestCase, self).__init__(*args, **kwargs)
