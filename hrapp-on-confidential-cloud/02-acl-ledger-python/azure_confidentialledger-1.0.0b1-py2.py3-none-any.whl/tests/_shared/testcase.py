from devtools_testutils import AzureTestCase


class ConfidentialLedgerTestCase(AzureTestCase):
    def __init__(self, *args, **kwargs):
        super(ConfidentialLedgerTestCase, self).__init__(*args, **kwargs)
